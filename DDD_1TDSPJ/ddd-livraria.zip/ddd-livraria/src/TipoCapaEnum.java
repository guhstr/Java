public enum TipoCapaEnum {
    //valores constante - escrita com letra maiúscula
    COMUM,
    DURA,
    PERSONALIZADA;

}
