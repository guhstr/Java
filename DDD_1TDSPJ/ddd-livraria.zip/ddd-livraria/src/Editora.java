public class Editora {
    String nome;
    String site;
    String telefone;

    public void exibirEditora(){
        System.out.println("Editora " + nome);
        System.out.println("Site: " + site);
        System.out.println("Telefone: " + telefone);
    }
}
