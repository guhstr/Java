public class TesteEditora {
    //Tipo nomeObjeto = new Construtor
    Editora editora = new Editora();
}
